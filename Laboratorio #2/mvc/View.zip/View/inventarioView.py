from Controller import inventarioController as controller

def menuInventario():
    print("1. Entrada")
    print("2. Salida")