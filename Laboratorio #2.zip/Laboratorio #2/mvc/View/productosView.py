def menuProductos():
    print("\nGestor de productos")
    print("1. Registrar")
    print("2. Listar")
    print("3. Modificar")
    print("4. Eliminar")
    print("5. Volver")