from Controller import productosController as controller

def menuProductos():
    print("1.Registrar")
    print("2.Listar")
    print("3.Modificar")
    print("4.Eliminar")

