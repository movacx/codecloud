def mostrarMensaje(mensaje):
    print(mensaje)
    
def mostrarDatos(dato):
    print(f"{dato}")