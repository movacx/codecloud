class Reportes(Producto):
	
	idReportes = 0
	def __init__(self, stock):
		super().__init__(stock)
		
		
	#Getters
	