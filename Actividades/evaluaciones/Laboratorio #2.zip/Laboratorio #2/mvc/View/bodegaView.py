def mostrarMenu():
    print("""
Sistema de Bodega
1. Gestión de Productos
2. Movimientos de Inventario
3. Reportes
4. Salir
""")

def mostrarMensaje(mensaje):
    print(f"*** {mensaje} ***")