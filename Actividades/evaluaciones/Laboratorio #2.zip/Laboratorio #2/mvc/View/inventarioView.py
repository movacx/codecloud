def menuInventario():
    print("\nInventario")
    print("1. Entrada")
    print("2. Salida")
    print("3. Volver")