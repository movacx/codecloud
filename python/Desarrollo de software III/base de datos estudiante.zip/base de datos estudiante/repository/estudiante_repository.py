"""
    Esta capa se encarga de comunicarse con la base de datos
    Aca se realizan las consultas sql
    INSERT
    SELECT
    UPDATE
    DELETE

    ACA
"""

from model.estudiante import Estudiante
from database.conexion import mysql

class EstudianteRepository:
    def __init__(self,estudiante):
        """
        Registra un estudiante en la base de datos
        estudiante: Objeto de tipo estudiante
        return un boolean indicando verdadero si el registro es exitoso
        """

        #Se obtiene la conexion a la base de datos
        conexion = obtener_conexion()

        #el cursor permite ejecutar
        cursor = conexion.cursor()

        #consulta sql parametrizada
        #se usa %s para evitar concatenar
        #datos(nombres de variables) en sql

        sql = """
        INSERT INTO estudiantes (nombre,correo,carrera)
        VALUES(%s, %s, %s)
        """

        #tupla con los valores que reemplazaran
        #los %s en la consulta

        valores = (estudiante.nombre, estudiante.correo, estudiante.carrera)

        #Ejecuta la consulta con sus valores
        cursor.execute(sql, valores)

        #confirma los cacmbios en la base de datos
        conexion.commit()
        #Se cierrra el cursor y la conexion para liberar recursos
        cursor.close()
        conexion.close()
        return True
    
    def consultar_todos(self):
        conexion = obtener_conexion()

        #el cursor permite ejecutar
        cursor = conexion.cursor()
        cursor.execute('SELECT id, nombre, correo, carrera FROM estudiante')

        #El metodo fetchall obteien todos los registros registrados
        registros = cursor.fetchall()

        #Lista donde se almacenaran los objetos estudiante
        estudiantes = []

        #se recorre cada registro devuelto por la base de datos

        for registro in registros:
            #cada registro es una tupla con el orden
            #id, nombre, correo, carrera
            estudiantes=estudiantes()

    