// obtiene el formulario por id
const formulario = document.getElementById('formulario');

// Evento submit
formulario.addEventListener('submit', function(event) {

    // muestra mensaje en consola
    console.log('Formulario enviado');

    // obtiene valores
    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;

    // validación básica
    if (nombre === "" || correo === "") {

        alert('Todos los campos son obligatorios');

        // cancelar envío
        event.preventDefault();
    }
});